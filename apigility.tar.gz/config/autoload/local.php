<?php
return [
    'db' => [
        'adapters' => [
            'basemybeef_basic_adapter' => [
                'database' => 'basemybeefnovo',
                'driver' => 'PDO_Mysql',
                'username' => 'root',
                'password' => 'mateusmoreira',
                'driver_options' => [
                    1002 => 'SET NAMES \'UTF8\'',
                ],
            ],
        ],
    ],
    'zf-mvc-auth' => [
        'authentication' => [
            'adapters' => [
                'oauth2mybeef' => [
                    'adapter' => \ZF\MvcAuth\Authentication\OAuth2Adapter::class,
                    'storage' => [
                        'adapter' => \pdo::class,
                        'dsn' => 'mysql:dbname:mybeefnovo:host:localhost',
                        'route' => '/oauth',
                        'username' => 'root',
                        'password' => 'mateusmoreira',
                    ],
                ],
            ],
        ],
    ],
];
