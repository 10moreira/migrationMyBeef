<?php
namespace MybeefAPI\V1\Rest\Medida;

use ArrayObject;

class MedidaEntity extends ArrayObject
{
}
