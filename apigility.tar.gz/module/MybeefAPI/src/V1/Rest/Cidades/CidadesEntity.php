<?php
namespace MybeefAPI\V1\Rest\Cidades;

use ArrayObject;

class CidadesEntity extends ArrayObject
{
}
