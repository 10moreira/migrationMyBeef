<?php
namespace MybeefAPI\V1\Rest\Cidades;

use Zend\Paginator\Paginator;

class CidadesCollection extends Paginator
{
}
