<?php
namespace MybeefAPI\V1\Rest\Receita;

use Zend\Paginator\Paginator;

class ReceitaCollection extends Paginator
{
}
