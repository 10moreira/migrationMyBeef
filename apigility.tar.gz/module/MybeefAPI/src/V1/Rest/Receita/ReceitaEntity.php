<?php
namespace MybeefAPI\V1\Rest\Receita;

use ArrayObject;

class ReceitaEntity extends ArrayObject
{
}
