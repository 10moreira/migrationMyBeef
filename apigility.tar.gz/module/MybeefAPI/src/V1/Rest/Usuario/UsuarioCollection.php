<?php
namespace MybeefAPI\V1\Rest\Usuario;

use Zend\Paginator\Paginator;

class UsuarioCollection extends Paginator
{
}
