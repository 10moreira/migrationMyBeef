<?php
namespace MybeefAPI\V1\Rest\Propriedade;

use ArrayObject;

class PropriedadeEntity extends ArrayObject
{
}
