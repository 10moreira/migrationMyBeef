<?php
namespace MybeefAPI\V1\Rest\Propriedade;

use Zend\Paginator\Paginator;

class PropriedadeCollection extends Paginator
{
}
