<?php
namespace MybeefAPI\V1\Rest\CategoriaAnimal;

use ArrayObject;

class CategoriaAnimalEntity extends ArrayObject
{
  
}
