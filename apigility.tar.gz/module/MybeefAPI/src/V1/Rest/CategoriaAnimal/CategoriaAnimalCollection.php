<?php
namespace MybeefAPI\V1\Rest\CategoriaAnimal;

use Zend\Paginator\Paginator;

class CategoriaAnimalCollection extends Paginator
{
}
