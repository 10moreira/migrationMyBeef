<?php
namespace MybeefAPI\V1\Rest\Rebanho;

use ArrayObject;

class RebanhoEntity extends ArrayObject
{
}
