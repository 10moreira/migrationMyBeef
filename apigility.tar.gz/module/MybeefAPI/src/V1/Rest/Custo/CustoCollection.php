<?php
namespace MybeefAPI\V1\Rest\Custo;

use Zend\Paginator\Paginator;

class CustoCollection extends Paginator
{
}
