<?php
namespace MybeefAPI\V1\Rest\Custo;

use ArrayObject;

class CustoEntity extends ArrayObject
{
}
