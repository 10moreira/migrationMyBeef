<?php
namespace MybeefAPI\V1\Rest\Estados;

use Zend\Paginator\Paginator;

class EstadosCollection extends Paginator
{
}
