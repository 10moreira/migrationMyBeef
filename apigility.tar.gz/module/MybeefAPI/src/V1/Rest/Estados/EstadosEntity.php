<?php
namespace MybeefAPI\V1\Rest\Estados;

use ArrayObject;

class EstadosEntity extends ArrayObject
{
}
