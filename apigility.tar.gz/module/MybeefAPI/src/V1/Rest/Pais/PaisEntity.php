<?php
namespace MybeefAPI\V1\Rest\Pais;

use ArrayObject;

class PaisEntity extends ArrayObject
{
}
