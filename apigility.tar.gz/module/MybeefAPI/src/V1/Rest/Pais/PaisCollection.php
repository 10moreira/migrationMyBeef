<?php
namespace MybeefAPI\V1\Rest\Pais;

use Zend\Paginator\Paginator;

class PaisCollection extends Paginator
{
}
