<?php
return [
    'router' => [
        'routes' => [
            'mybeef-api.rest.categoria-animal' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/categoria_animal[/:categoria_animal_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.cidades' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/cidades[/:cidades_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Cidades\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.custo' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/custo[/:custo_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Custo\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.estados' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/estados[/:estados_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Estados\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.medida' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/medida[/:medida_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Medida\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.pais' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/pais[/:pais_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Pais\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.propriedade' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/propriedade[/:propriedade_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Propriedade\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.rebanho' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/rebanho[/:rebanho_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Rebanho\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.receita' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/receita[/:receita_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Receita\\Controller',
                    ],
                ],
            ],
            'mybeef-api.rest.usuario' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/usuario[/:usuario_id]',
                    'defaults' => [
                        'controller' => 'MybeefAPI\\V1\\Rest\\Usuario\\Controller',
                    ],
                ],
            ],
        ],
    ],
    'zf-versioning' => [
        'uri' => [
            0 => 'mybeef-api.rest.categoria-animal',
            1 => 'mybeef-api.rest.cidades',
            2 => 'mybeef-api.rest.custo',
            3 => 'mybeef-api.rest.estados',
            4 => 'mybeef-api.rest.medida',
            5 => 'mybeef-api.rest.pais',
            6 => 'mybeef-api.rest.propriedade',
            7 => 'mybeef-api.rest.rebanho',
            8 => 'mybeef-api.rest.receita',
            9 => 'mybeef-api.rest.usuario',
        ],
        'default_version' => 1,
    ],
    'zf-rest' => [
        'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\CategoriaAnimalResource',
            'route_name' => 'mybeef-api.rest.categoria-animal',
            'route_identifier_name' => 'categoria_animal_id',
            'collection_name' => 'categoria_animal',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\CategoriaAnimal\CategoriaAnimalEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\CategoriaAnimal\CategoriaAnimalCollection::class,
            'service_name' => 'categoria_animal',
        ],
        'MybeefAPI\\V1\\Rest\\Cidades\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Cidades\\CidadesResource',
            'route_name' => 'mybeef-api.rest.cidades',
            'route_identifier_name' => 'cidades_id',
            'collection_name' => 'cidades',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Cidades\CidadesEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Cidades\CidadesCollection::class,
            'service_name' => 'cidades',
        ],
        'MybeefAPI\\V1\\Rest\\Custo\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Custo\\CustoResource',
            'route_name' => 'mybeef-api.rest.custo',
            'route_identifier_name' => 'custo_id',
            'collection_name' => 'custo',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Custo\CustoEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Custo\CustoCollection::class,
            'service_name' => 'custo',
        ],
        'MybeefAPI\\V1\\Rest\\Estados\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Estados\\EstadosResource',
            'route_name' => 'mybeef-api.rest.estados',
            'route_identifier_name' => 'estados_id',
            'collection_name' => 'estados',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Estados\EstadosEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Estados\EstadosCollection::class,
            'service_name' => 'estados',
        ],
        'MybeefAPI\\V1\\Rest\\Medida\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Medida\\MedidaResource',
            'route_name' => 'mybeef-api.rest.medida',
            'route_identifier_name' => 'medida_id',
            'collection_name' => 'medida',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Medida\MedidaEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Medida\MedidaCollection::class,
            'service_name' => 'medida',
        ],
        'MybeefAPI\\V1\\Rest\\Pais\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Pais\\PaisResource',
            'route_name' => 'mybeef-api.rest.pais',
            'route_identifier_name' => 'pais_id',
            'collection_name' => 'pais',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Pais\PaisEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Pais\PaisCollection::class,
            'service_name' => 'pais',
        ],
        'MybeefAPI\\V1\\Rest\\Propriedade\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Propriedade\\PropriedadeResource',
            'route_name' => 'mybeef-api.rest.propriedade',
            'route_identifier_name' => 'propriedade_id',
            'collection_name' => 'propriedade',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Propriedade\PropriedadeEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Propriedade\PropriedadeCollection::class,
            'service_name' => 'propriedade',
        ],
        'MybeefAPI\\V1\\Rest\\Rebanho\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Rebanho\\RebanhoResource',
            'route_name' => 'mybeef-api.rest.rebanho',
            'route_identifier_name' => 'rebanho_id',
            'collection_name' => 'rebanho',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Rebanho\RebanhoEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Rebanho\RebanhoCollection::class,
            'service_name' => 'rebanho',
        ],
        'MybeefAPI\\V1\\Rest\\Receita\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Receita\\ReceitaResource',
            'route_name' => 'mybeef-api.rest.receita',
            'route_identifier_name' => 'receita_id',
            'collection_name' => 'receita',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Receita\ReceitaEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Receita\ReceitaCollection::class,
            'service_name' => 'receita',
        ],
        'MybeefAPI\\V1\\Rest\\Usuario\\Controller' => [
            'listener' => 'MybeefAPI\\V1\\Rest\\Usuario\\UsuarioResource',
            'route_name' => 'mybeef-api.rest.usuario',
            'route_identifier_name' => 'usuario_id',
            'collection_name' => 'usuario',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \MybeefAPI\V1\Rest\Usuario\UsuarioEntity::class,
            'collection_class' => \MybeefAPI\V1\Rest\Usuario\UsuarioCollection::class,
            'service_name' => 'usuario',
        ],
    ],
    'zf-content-negotiation' => [
        'controllers' => [
            'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Cidades\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Custo\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Estados\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Medida\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Pais\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Propriedade\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Rebanho\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Receita\\Controller' => 'HalJson',
            'MybeefAPI\\V1\\Rest\\Usuario\\Controller' => 'HalJson',
        ],
        'accept_whitelist' => [
            'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Cidades\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Custo\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Estados\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Medida\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Pais\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Propriedade\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Rebanho\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Receita\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Usuario\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
        ],
        'content_type_whitelist' => [
            'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Cidades\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Custo\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Estados\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Medida\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Pais\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Propriedade\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Rebanho\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Receita\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
            'MybeefAPI\\V1\\Rest\\Usuario\\Controller' => [
                0 => 'application/vnd.mybeef-api.v1+json',
                1 => 'application/json',
            ],
        ],
    ],
    'zf-hal' => [
        'metadata_map' => [
            \MybeefAPI\V1\Rest\CategoriaAnimal\CategoriaAnimalEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.categoria-animal',
                'route_identifier_name' => 'categoria_animal_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\CategoriaAnimal\CategoriaAnimalCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.categoria-animal',
                'route_identifier_name' => 'categoria_animal_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Cidades\CidadesEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.cidades',
                'route_identifier_name' => 'cidades_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Cidades\CidadesCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.cidades',
                'route_identifier_name' => 'cidades_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Custo\CustoEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.custo',
                'route_identifier_name' => 'custo_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Custo\CustoCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.custo',
                'route_identifier_name' => 'custo_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Estados\EstadosEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.estados',
                'route_identifier_name' => 'estados_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Estados\EstadosCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.estados',
                'route_identifier_name' => 'estados_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Medida\MedidaEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.medida',
                'route_identifier_name' => 'medida_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Medida\MedidaCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.medida',
                'route_identifier_name' => 'medida_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Pais\PaisEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.pais',
                'route_identifier_name' => 'pais_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Pais\PaisCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.pais',
                'route_identifier_name' => 'pais_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Propriedade\PropriedadeEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.propriedade',
                'route_identifier_name' => 'propriedade_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Propriedade\PropriedadeCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.propriedade',
                'route_identifier_name' => 'propriedade_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Rebanho\RebanhoEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.rebanho',
                'route_identifier_name' => 'rebanho_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Rebanho\RebanhoCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.rebanho',
                'route_identifier_name' => 'rebanho_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Receita\ReceitaEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.receita',
                'route_identifier_name' => 'receita_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Receita\ReceitaCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.receita',
                'route_identifier_name' => 'receita_id',
                'is_collection' => true,
            ],
            \MybeefAPI\V1\Rest\Usuario\UsuarioEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.usuario',
                'route_identifier_name' => 'usuario_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \MybeefAPI\V1\Rest\Usuario\UsuarioCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'mybeef-api.rest.usuario',
                'route_identifier_name' => 'usuario_id',
                'is_collection' => true,
            ],
        ],
    ],
    'zf-apigility' => [
        'db-connected' => [
            'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\CategoriaAnimalResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'categoria_animal',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\CategoriaAnimalResource\\Table',
            ],
            'MybeefAPI\\V1\\Rest\\Cidades\\CidadesResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'cidades',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Cidades\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Custo\\CustoResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'custo',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Custo\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Estados\\EstadosResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'estados',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Estados\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Medida\\MedidaResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'medida',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Medida\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Pais\\PaisResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'pais',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Pais\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Propriedade\\PropriedadeResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'propriedade',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Propriedade\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Rebanho\\RebanhoResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'rebanho',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Rebanho\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Receita\\ReceitaResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'receita',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Receita\\Controller',
                'entity_identifier_name' => 'id',
            ],
            'MybeefAPI\\V1\\Rest\\Usuario\\UsuarioResource' => [
                'adapter_name' => 'basemybeef_basic_adapter',
                'table_name' => 'usuario',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'MybeefAPI\\V1\\Rest\\Usuario\\Controller',
                'entity_identifier_name' => 'id',
            ],
        ],
    ],
    'zf-content-validation' => [
        'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Cidades\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Cidades\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Custo\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Custo\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Estados\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Estados\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Medida\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Medida\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Pais\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Pais\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Propriedade\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Propriedade\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Rebanho\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Rebanho\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Receita\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Receita\\Validator',
        ],
        'MybeefAPI\\V1\\Rest\\Usuario\\Controller' => [
            'input_filter' => 'MybeefAPI\\V1\\Rest\\Usuario\\Validator',
        ],
    ],
    'input_filter_specs' => [
        'MybeefAPI\\V1\\Rest\\CategoriaAnimal\\Validator' => [
            0 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '30',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Cidades\\Validator' => [
            0 => [
                'name' => 'pais_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'pais',
                            'field' => 'id',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'estados_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'estados',
                            'field' => 'id',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '120',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Custo\\Validator' => [
            0 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'categoria',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'data',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            3 => [
                'name' => 'valor',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Estados\\Validator' => [
            0 => [
                'name' => 'pais_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'pais',
                            'field' => 'id',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '100',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'sigla',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Medida\\Validator' => [
            0 => [
                'name' => 'valor',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            1 => [
                'name' => 'ano',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Pais\\Validator' => [
            0 => [
                'name' => 'paisNome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '50',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'paisName',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '50',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Propriedade\\Validator' => [
            0 => [
                'name' => 'usuario_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'cidades_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'pais_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            3 => [
                'name' => 'data',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            5 => [
                'name' => 'nro_car',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            6 => [
                'name' => 'tamanho',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            7 => [
                'name' => 'localidade',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Rebanho\\Validator' => [
            0 => [
                'name' => 'ano',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'categoria_animal_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            3 => [
                'name' => 'qtd_estocada',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'peso_estocado',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            5 => [
                'name' => 'qtd_vendida',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            6 => [
                'name' => 'peso_vendido',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Receita\\Validator' => [
            0 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'data',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            2 => [
                'name' => 'quantidade',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            3 => [
                'name' => 'peso',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'preco',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\Usuario\\Validator' => [
            0 => [
                'name' => 'cidades_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'cidades',
                            'field' => 'id',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'pais_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'pais',
                            'field' => 'id',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'login',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbNoRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'usuario',
                            'field' => 'login',
                        ],
                    ],
                    1 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '45',
                        ],
                    ],
                ],
            ],
            3 => [
                'name' => 'email',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbNoRecordExists',
                        'options' => [
                            'adapter' => 'basemybeef_basic_adapter',
                            'table' => 'usuario',
                            'field' => 'email',
                        ],
                    ],
                    1 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            4 => [
                'name' => 'senha',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '128',
                        ],
                    ],
                ],
            ],
            5 => [
                'name' => 'perfil',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            6 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            7 => [
                'name' => 'localidade',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            8 => [
                'name' => 'telefone',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '20',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthAccessTokens\\Validator' => [
            0 => [
                'name' => 'client_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'user_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'expires',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            3 => [
                'name' => 'scope',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthAuthorizationCodes\\Validator' => [
            0 => [
                'name' => 'client_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'user_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'redirect_uri',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
            3 => [
                'name' => 'expires',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'scope',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
            5 => [
                'name' => 'id_token',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthUsers\\Validator' => [
            0 => [
                'name' => 'password',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'first_name',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'last_name',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthScopes\\Validator' => [
            0 => [
                'name' => 'type',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'scope',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'client_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            3 => [
                'name' => 'is_default',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthClients\\Validator' => [
            0 => [
                'name' => 'client_secret',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'redirect_uri',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'grant_types',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            3 => [
                'name' => 'scope',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
            4 => [
                'name' => 'user_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthJwt\\Validator' => [
            0 => [
                'name' => 'subject',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'public_key',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
        ],
        'MybeefAPI\\V1\\Rest\\OauthRefreshTokens\\Validator' => [
            0 => [
                'name' => 'client_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '80',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'user_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '255',
                        ],
                    ],
                ],
            ],
            2 => [
                'name' => 'expires',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            3 => [
                'name' => 'scope',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '2000',
                        ],
                    ],
                ],
            ],
        ],
    ],
    'service_manager' => [
        'factories' => [],
    ],
];
