export class CategoriaAnimal {
    id:number;
    nomeCategoria:string;

}