export class Medida {
    id:number;
    valor:number;
    ano:number;
    propriedade_id: number;
}