"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Medida = /** @class */ (function () {
    function Medida() {
    }
    return Medida;
}());
exports.Medida = Medida;
//# sourceMappingURL=medida.js.map