export class Propriedade {
    id: number;
    usuario_id: number;
    cidades_id: number;
    pais_id: number;
    data: string;
    nome: string;
    nro_car: string;
    tamanho: number;
    localidade: string

}