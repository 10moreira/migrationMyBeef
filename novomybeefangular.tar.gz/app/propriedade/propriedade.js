"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Propriedade = /** @class */ (function () {
    function Propriedade() {
    }
    return Propriedade;
}());
exports.Propriedade = Propriedade;
//# sourceMappingURL=propriedade.js.map