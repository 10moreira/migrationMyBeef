"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var usuario_service_1 = require("./usuario.service");
var router_1 = require("@angular/router");
var message_service_1 = require("../message.service");
var UsuarioEditComponent = /** @class */ (function () {
    function UsuarioEditComponent(usuarioService, route, router, messageService) {
        this.usuarioService = usuarioService;
        this.route = route;
        this.router = router;
        this.messageService = messageService;
    }
    UsuarioEditComponent.prototype.submit = function () {
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Usuario alterada com sucesso'
        });
        this.router.navigate(['usuarios', 'list']);
    };
    UsuarioEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            var id = +params['id'];
            _this.usuario = _this.usuarioService.getUsuario(id);
            if (!_this.usuario) {
                alert('Usuario não existe');
            }
        });
    };
    UsuarioEditComponent = __decorate([
        core_1.Component({
            selector: 'usuario-edit',
            templateUrl: 'usuario-edit.component.html',
            moduleId: module.id
        }),
        __metadata("design:paramtypes", [usuario_service_1.UsuarioService,
            router_1.ActivatedRoute,
            router_1.Router,
            message_service_1.MessageService])
    ], UsuarioEditComponent);
    return UsuarioEditComponent;
}());
exports.UsuarioEditComponent = UsuarioEditComponent;
//# sourceMappingURL=usuario-edit.component.js.map