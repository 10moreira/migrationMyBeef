export class Usuario{
    id: number;
    cidades_id: number;
    pais_id: number;
    login: string;
    email: string;
    senha: string;
    perfil: string;
    nome: string;
    localidade: string;
    telefone: string

}