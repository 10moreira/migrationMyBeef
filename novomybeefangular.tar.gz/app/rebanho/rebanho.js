"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Rebanho = /** @class */ (function () {
    function Rebanho() {
    }
    return Rebanho;
}());
exports.Rebanho = Rebanho;
//# sourceMappingURL=rebanho.js.map