export class Rebanho {
    id: number;
    ano: number;
    propriedade_id: number;
    categoria_animal_id: number;
    qtd_estocada: number;
    peso_estocado: number;
    qtd_vendida: number;
    peso_vendido: number

}